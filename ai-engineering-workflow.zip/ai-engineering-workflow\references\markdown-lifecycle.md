# Markdown 长度预算与生命周期协议

目标：让 Markdown 始终可读、可恢复、可交接。AI 不应把状态、历史、实验细节和完整日志不断追加到同一个文件里。

## 触发条件

- 准备新增或追加 Markdown 内容。
- 某个 Markdown 已经很长，影响开工读取、评审或交接。
- 同一文件里同时混有当前状态、历史流水、废弃方案、完整实验细节或重复说明。
- 用户要求“压缩”“归档”“别让文档太长”“整理一下文档”。

## 长度预算

用行数和文件大小双重判断；任一项超过即触发对应等级。

| 文件类型 | 建议预算 | 硬上限 | 超限处理 |
| --- | ---: | ---: | --- |
| `STATUS.md`、`docs/README.md` | 200 行或 12 KB | 300 行或 20 KB | 只保留当前焦点、下一步、索引和最近交接；旧交接归档 |
| `PROJECT_MEMORY.md` | 300 行或 20 KB | 450 行或 32 KB | 只保留当前有效结论、当前最优、待确认假设和来源链接；历史结果归档 |
| `TASK_SPEC.md`、`data/README.md` | 400 行或 32 KB | 600 行或 48 KB | 保留当前标准；版本历史、旧规则和长示例拆到专门文档 |
| `experiments/CHANGELOG.md` | 500 行或 48 KB | 800 行或 80 KB | 按阶段或日期拆分；主文件只保留索引、当前比较组和最近决策 |
| 单次 `experiments/*/report.md` | 500 行或 48 KB | 700 行或 80 KB | 详细 badcase、日志和样例放到 `artifacts/` 或附录文件 |
| 使用手册、设计文档、决策说明 | 600 行或 64 KB | 900 行或 96 KB | 按主题拆分，入口文档只保留导航和关键结论 |
| Skill `references/*.md` | 700 行或 80 KB | 900 行或 110 KB | 新协议拆成独立 reference；旧协议按主题拆分 |

任何 Markdown 超过硬上限时，不得继续追加正文；必须先压缩、归档、拆分或淘汰。

## 硬边界检查脚本

新增或追加 Markdown 前，必须先运行：

```bash
python <skill-dir>/scripts/check_markdown_budget.py <project-root-or-markdown-file>
```

脚本只检测，不自动修改文件。默认递归扫描目录中的 Markdown，并忽略 `.git/`、`node_modules/`、`tmp/`、`log/`、缓存目录等生成物；直接传入具体文件时即使位于这些目录也会检查。

退出码：

- `0`：未达到失败阈值。
- `1`：在 `--fail-on budget` 或更严格模式下超过建议预算。
- `2`：超过 hard limit。不得继续追加正文，必须先压缩、归档、拆分或淘汰。
- `3`：在 `--fail-on near` 模式下接近建议预算。

常用命令：

```bash
# 默认只在超过 hard limit 时失败，只展示 near/over/hard 问题
python <skill-dir>/scripts/check_markdown_budget.py <project-root>

# 作为更严格的写入前检查：超过建议预算也失败
python <skill-dir>/scripts/check_markdown_budget.py <project-root> --fail-on budget

# 输出机器可读结果
python <skill-dir>/scripts/check_markdown_budget.py <project-root> --json-out markdown_budget.json
```

## 处理顺序

1. 先测量：记录目标文件行数、大小、用途和是否接近预算。
2. 再分类内容：
   - 当前有效：仍指导下一步决策、运行或验收。
   - 待确认：需要用户裁定，保留问题、影响和下一步。
   - 历史可追溯：旧实验、旧结论、被覆盖方案、完整交接。
   - 无决策价值：重复解释、过期 TODO、已失效草稿、冗余日志。
3. 按优先级处理：
   - 压缩当前有效内容：保留结论、依据、适用条件、来源链接。
   - 归档历史内容：移动到 `docs/archive/<doc-stem>/YYYY-MM-DD-<topic>.md`、`experiments/CHANGELOG.md` 或实验目录。
   - 拆分长主题：把长章节拆到独立文件，入口文档只保留摘要和链接。
   - 淘汰无价值内容：删除重复或过期内容；若可能有争议，先标记 `superseded` 或 `archived`，不要静默删除关键结论。
4. 最后再写新内容，并在入口文档留下归档链接、更新时间和当前有效摘要。

## 不同文件的保留规则

- `STATUS.md`：只保留当前工作焦点、当前阶段、阻塞、下一步、最近一次交接和待用户确认项。最多保留最近 3 次交接摘要。
- `PROJECT_MEMORY.md`：只保留当前仍有决策价值的压缩记忆；当前推荐方案只保留一个。历史候选保留链接，不保留全文。
- `docs/README.md`：只能做索引和维护规则，不写长篇说明、实验复盘或使用手册正文。
- `TASK_SPEC.md`：只保留当前任务定义、当前指标、当前验收线和当前边界。旧版本写入“版本历史索引”，正文移走。
- `experiments/CHANGELOG.md`：保留实验索引、比较组、晋升/回滚决策和不可比较说明；单次实验细节留在对应报告。
- `report.md`：保留人要读的结论、指标、关键 badcase 和下一轮建议；完整日志、全量样例和大表格不要塞进报告正文。

## 归档命名

默认归档位置：

```text
docs/archive/<doc-stem>/YYYY-MM-DD-<short-topic>.md
```

实验相关历史优先放：

```text
experiments/<experiment_id>/artifacts/
experiments/archive/
```

归档文件顶部必须写：

```markdown
# <原主题>
- 来源文件：
- 归档时间：
- 归档原因：
- 当前有效摘要位置：
- 是否仍可比较/仍有效：
```

## 交付前检查

- 是否有 Markdown 超过硬上限。
- 是否把历史流水、完整日志或重复解释塞进当前工作文件。
- 是否在入口文件留下归档链接。
- 是否保留了来源、时间、适用条件和当前有效摘要。
- 是否误删了 GT、指标、验收线、历史结论或用户裁定；这些内容只能压缩或归档，不能无记录淘汰。
